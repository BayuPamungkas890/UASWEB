@include('frontend.header')
	<!-- New Arrivals section start -->
  <div class="collection_text">Sendal</div>
    <div class="collection_section layout_padding">
    	<div class="container">
    		<h1 class="new_text"><strong><font color="white">Koleksi Sendal</font></strong></h1>
    	    <p class="consectetur_text"><font color="white"> Produk terbaik dari Toko Kami.</p>
    	</div>
    </div>
    @php
$sandal = App\Sandal::orderby('created_at','DESC')->get();
@endphp

	<!-- New Arrivals section start -->
    <div class="layout_padding gallery_section">
    	<div class="container">
    		<div class="row">
    		@foreach ($sandal as $sans)	
            <div class="col-sm-4">
                
    				<div class="best_shoes">
    					<p class="best_text"><center><h5>{{ $sans->nama }}</h5></center></p>
						<center><h5>- {{ $sans->Merk->nama_merk }} -</h5></center></p>
    					<div class="shoes_icon"><img src="{{ asset('assets/images/avatar/'.$sans->gambar.'') }}" style="width: 250px; height: 300px;"></div>
    					<div class="star_text">
    						<div class="right_part">
    							<div class="shoes_price"><h4>Rp. <span style="color: #ff4e5b;">{{ number_format($sans->harga,2,',','.') }}</span></h4></div>
								<br>
								<center><a href="{{url('add-cart',$sans->id)}}" class="btn btn-primary" style="width: 250px; margin-left: 50px;">Beli</a></center>
    						</div>
    					</div>
    				</div>
                
    			</div>
                @endforeach        
    		</div>
            
    		</div>
</div>
   	<!-- New Arrivals section end -->
       @include('frontend.chat')
	<!-- section footer start -->
    	@include('frontend.footer')
