<!DOCTYPE html>
<html lang="en">
   <head>
      <!-- basic -->
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <!-- mobile metas -->
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="viewport" content="initial-scale=1, maximum-scale=1">
      <!-- site metas -->
      <title>Toko Sendal</title>
      <meta name="keywords" content="">
      <meta name="description" content="">
      <meta name="author" content="">
      <!-- bootstrap css -->
      <link rel="stylesheet" href="/assets/front/css/bootstrap.min.css">
      <!-- style css -->
      <link rel="stylesheet" href="/assets/front/css/style.css">
      <!-- Responsive-->
      <link rel="stylesheet" href="/assets/front/css/responsive.css">
      <!-- fevicon -->
      <link rel="icon" href="/assets/front/images/fevicon.png" type="image/gif" />
      <!-- Scrollbar Custom CSS -->
      <link rel="stylesheet" href="/assets/front/css/jquery.mCustomScrollbar.min.css">
      <!-- Tweaks for older IEs-->
      <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css">
      <!-- owl stylesheets --> 
      <link rel="stylesheet" href="/assets/front/css/owl.carousel.min.css">
      <link rel="stylesheet" href="/assets/front/css/owl.theme.default.min.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">
      <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
   </head>
   <!-- body -->
   <body class="main-layout">
	<!-- header section start -->
<div class="header_section">
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="logo"><a href="#"><img src="/assets/img/aa.png"></a></div>
				</div>
				<div class="col-sm-9">
					<nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        </button>
                    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                        <div class="navbar-nav">
                           <a class="nav-item nav-link" href="/">Home</a>
                           <a class="nav-item nav-link" href="/sendal">Sendal</a>
                           <a class="nav-item nav-link" href="/terbaru">Terbaru</a>
                           <a class="nav-item nav-link" href="/rekomendasi">Rekomendasi</a>
                           @php
							if(\Auth::check()){
								$cart = \App\Cart::where('user_id', \Auth::user()->id);
							}
						@endphp
                  @if(Auth::check() && $cart->count() > 0)
                           <a class="nav-item nav-link" href="{{url('cart', Auth::user()->id)}}">
                           <img src="/assets/front/images/shop_icon.png">@endif</a>
                           @guest
                                <a class="nav-item nav-link" href="{{ route('login') }}"><i class="fa fa-sign-in nav-item"> Login</i></a>
                        	@else
                            
        <a class="nav-item nav-link" data-widget="Logout" data-slide="true" href="{{ route('logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i
            class="fa fa-sign-out"></i> Logout</a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
      </li>
                        @endguest
                        </div>
                    </div>
                    </nav>
				</div>
			</div>
		</div>