<div class="section_footer">
    	<div class="container">
    		<div class="mail_section">
    			<div class="row">
    				<div class="col-sm-6 col-lg-2">
    					<div><a href="#"><img src="/assets/img/Tos.png"></a></div>
    				</div>
    				<div class="col-sm-6 col-lg-2">
    					<div class="footer-logo"><img src="/assets/front/images/phone-icon.png"><span class="map_text">(022) 220</span></div>
    				</div>
    				<div class="col-sm-6 col-lg-3">
    					<div class="footer-logo"><img src="/assets/front/images/email-icon.png"><span class="map_text">tosce@gmail.com</span></div>
    				</div>
    				<div class="col-sm-6 col-lg-3">
    					<div class="social_icon">
    						<ul>
    							
    						</ul>
    					</div>
    				</div>
    				<div class="col-sm-2"></div>
    			</div>
    	    </div> 
    	    <div class="footer_section_2">
		        <div class="row">
    		        <div class="col-sm-4 col-lg-2">
    		        	<p class="dummy_text"> Ayo segera miliki sandalnya untuk menambah koleksi sandal anda, warnai hari-hari anda dengan pilihan yang terbaik dan terbaru dari kami.</p>
    		        </div>
    		        <div class="col-sm-4 col-lg-2">
    		        	<h2 class="shop_text">Alamat </h2>
    		        	<div class="image-icon"><img src="/assets/front/images/map-icon.png"><span class="pet_text">Jl. Jenderal Soedirman No.181, Cibadak Kec. Astanaanyar, Kota Bandung, Jawa Barat, 40421</span></div>
    		        </div>
    		        <div class="col-sm-4 col-md-6 col-lg-3">
    				    <h2 class="shop_text">Info</h2>
    				    <div class="delivery_text">
    				    	<ul>
    				    		<li>About us</li>
    				    		<li>Contact us</li>
    				    	</ul>
    				    </div>
    		        </div>
    			
    			
    			</div>
    	        </div> 
	        </div>
    	</div>
    </div>
	<!-- section footer end -->
	
	<!-- Javascript files-->
	<script src="/assets/front/js/jquery.min.js"></script>
      <script src="/assets/front/js/popper.min.js"></script>
      <script src="/assets/front/js/bootstrap.bundle.min.js"></script>
      <script src="/assets/front/js/jquery-3.0.0.min.js"></script>
      <script src="/assets/front/js/plugin.js"></script>
      <!-- sidebar -->
      <script src="/assets/front/js/jquery.mCustomScrollbar.concat.min.js"></script>
      <script src="/assets/front/js/custom.js"></script>
      <!-- javascript --> 
      <script src="/assets/front/js/owl.carousel.js"></script>
      <script src="https:cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.js"></script>
      <script>
         $(document).ready(function(){
         $(".fancybox").fancybox({
         openEffect: "none",
         closeEffect: "none"
         });
         
         
$('#myCarousel').carousel({
            interval: false
        });

        //scroll slides on swipe for touch enabled devices

        $("#myCarousel").on("touchstart", function(event){

            var yClick = event.originalEvent.touches[0].pageY;
            $(this).one("touchmove", function(event){

                var yMove = event.originalEvent.touches[0].pageY;
                if( Math.floor(yClick - yMove) > 1 ){
                    $(".carousel").carousel('next');
                }
                else if( Math.floor(yClick - yMove) < -1 ){
                    $(".carousel").carousel('prev');
                }
            });
            $(".carousel").on("touchend", function(){
                $(this).off("touchmove");
            });
        });
      </script> 
   </body>
</html>