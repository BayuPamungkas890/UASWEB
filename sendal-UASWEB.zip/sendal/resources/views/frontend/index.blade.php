	@include('frontend.header')
		<div class="banner_section">
			<div class="container-fluid">
				<section class="slide-wrapper">
    <div class="container-fluid">
	    <div id="myCarousel" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                <li data-target="#myCarousel" data-slide-to="1"></li>
                <li data-target="#myCarousel" data-slide-to="2"></li>
                <li data-target="#myCarousel" data-slide-to="3"></li>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <div class="row">
					<div class="col-sm-2 padding_0">
						<p class="mens_taital"></p>
						<div class="page_no">1/2</div>
					</div>
					<div class="col-sm-5">
                    <div class="banner_taital">
								<h1 class="banner_text">Sendal Kekinian</h1>
								<h1 class="mens_text"><strong>Sendal Flip Flop Perempuan</strong></h1>
								<p class="lorem_text">Di pasaran banyak lho tipe sandal dan merek-merek lain yang cukup terkenal dan bisa membuat kamu terlihat lebih stylish dan mencerminkan gaya masa sekarang. Saat memilih sandal, 
                                    kamu juga harus tahu yang mana yang berkualitas dan akan selalu nyaman ketika dipakai lama.</p>
								
							</div>
					</div>
					<div class="col-sm-5">
						<div class="shoes_img"><img src="/assets/img/1.png"></div>
					</div>
				</div>
                </div>
                
                <div class="carousel-item">
					<div class="row">
						<div class="col-sm-2 padding_0">
							<p class="mens_taital"></p>
							<div class="page_no">2/2</div>
						</div>
						<div class="col-sm-5">
							<div class="banner_taital">
								<h1 class="banner_text">Sendal Kekinian</h1>
								<h1 class="mens_text"><strong>Sendal Flip Flop Perempuan</strong></h1>
								<p class="lorem_text">Di pasaran banyak lho tipe sandal dan merek-merek lain yang cukup terkenal dan bisa membuat kamu terlihat lebih stylish dan mencerminkan gaya masa sekarang. Saat memilih sandal, 
                                    kamu juga harus tahu yang mana yang berkualitas dan akan selalu nyaman ketika dipakai lama.</p>
								
							</div>
					</div>
					<div class="col-sm-5">
						<div class="shoes_img"><img src="/assets/img/2.png"></div>
					</div>
				</div>
                </div>
            </div>
        </div>
    </div>
</section>			
			</div>
		</div>
	</div>
	<!-- header section end -->
	<!-- new collection section start -->
    <div class="layout_padding collection_section">
    	<div class="container">
    	    <h1 class="new_text"><strong>Sendal Terbaru</strong></h1>
    	    <p class="consectetur_text">Hi-Jack Sandals menawarkan pilihan sandal dengan warna dan desain yang variatif dengan bahan berkualitas yang nyaman.

Produk sandal buatan lokal ini juga memiliki arch support agar kakimu tidak cepat lelah dan pegal dan juga air scoop system yang menyejukkan kaki dan menghindari keingat.</p>
<div class="collection_section_2">
    	    	<div class="row">
                @php
                $sandal = App\Sandal::orderby('created_at','DESC')->paginate(1);
                @endphp
                @foreach ($sandal as $sans)
				<div class="col-md-6">
    	    			<div class="about-img">
						<button class="new_bt">New</button>
    	    				<div class="shoes-img"><img src="{{ asset('assets/images/avatar/'.$sans->gambar.'') }}"></div>
    	    				<p class="sport_text">{{ $sans->nama }}</p>
    	    				<div class="dolar_text"><h3>Rp. <span style="color: #ff4e5b;">{{ number_format($sans->harga,2,',','.') }}</span></h3></center></div>
							<br>
							<center><a href="{{url('add-cart',$sans->id)}}" class="btn btn-primary" style="width: 250px; margin-left: 10px;">Beli</a></center>
							<br>
						</div>
    	    		</div>
                @endforeach
                @php
				$sandal = App\Sandal::orderbyRaw("RAND()")->paginate(1);
                @endphp
                @foreach ($sandal as $sanst)    
				<div class="col-md-6">
    	    			<div class="about-img">
    	    				<div class="shoes-img"><img src="{{ asset('assets/images/avatar/'.$sanst->gambar.'') }}"></div>
    	    				<p class="sport_text">{{ $sanst->nama }}</p>
    	    				<div class="dolar_text"<h3>Rp. <span style="color: #ff4e5b;">{{ number_format($sanst->harga,2,',','.') }}</span></h3></center></div>
							<br>
							<center><a href="{{url('add-cart',$sanst->id)}}" class="btn btn-primary" style="width: 250px; margin-left: 10px;">Beli</a></center>
							<br>
						</div>
    	    		</div>
                    @endforeach
    	    	</div>
    	    </div>
    	</div>
    </div>
	</div>
    <div class="collection_section">
    	<div class="container">
    		<h1 class="new_text"><strong>Recomend Sendal</strong></h1>
    	    <p class="consectetur_text">Hipzo Original Produk Kebanggaan anak bangsa dengan Kualitas International Model dan design Elegan dan Kekinian. Bahan Pilihan, Kualitas terjaga .</p>
    	</div>
    </div>
    <div class="collectipn_section_3 layuot_padding">
    	<div class="container">
    		<div class="racing_shoes">
			<div class="row">
				@php
                $sandal = App\Sandal::find([11]);
                @endphp
				@foreach ($sandal as $sans)
    				<div class="col-md-8">
    					<div class="shoes-img"><img src="{{ asset('assets/images/avatar/'.$sans->gambar.'') }}"></div>
    				</div>
    				<div class="col-md-4">
    					<div class="sale_text"><strong>Recomend <br><span style="color: #0a0506;">{{ $sans->nama }}</span></strong></div>
    					<div class="number_text"><strong>Rp. <span style="color: #ff4e5b;">{{ number_format($sans->harga,2,',','.') }}</span></strong></div>
    					<br>
							<center><a href="{{url('add-cart',$sans->id)}}" class="btn btn-primary" style="width: 250px; margin-left: 10px;">Beli</a></center>
							<br>
    				</div>
    			</div>
				@endforeach
    		</div>
    		</div>
    	</div>
    </div>
	<!-- new collection section end -->

	@php
	$sandal = App\Sandal::orderbyRaw("RAND()")->paginate(3);
@endphp

	<!-- New Arrivals section start -->
    <div class="layout_padding gallery_section">
    	<div class="container">
    		<div class="row">
    		@foreach ($sandal as $sans)	
            <div class="col-sm-4">
                
    				<div class="best_shoes">
    					<p class="best_text">{{ $sans->nama }}</p>
    					<div class="shoes_icon"><img src="{{ asset('assets/images/avatar/'.$sans->gambar.'') }}" style="width: 250px; height: 300px;"></div>
    					<div class="star_text">
    						<div class="right_part">
    							<div class="shoes_price"><h3>Rp. <span style="color: #ff4e5b;">{{ number_format($sans->harga,2,',','.') }}</span></h3></center></div>
								<br>
								<center><a href="{{url('add-cart',$sans->id)}}" class="btn btn-primary" style="width: 250px; margin-left: 50px;">Beli</a></center>
    						</div>
    					</div>
    				</div>
                
    			</div>
                @endforeach        
    		</div>
            
    		</div>
</div>
</div>
   	<!-- New Arrivals section end -->
   	<!-- contact section start -->
    @include('frontend.chat')
   	<!-- contact section end -->

	<!-- section footer start -->
    @include('frontend.footer')


      