@include('frontend.header')
	<!-- New Arrivals section start -->
  <div class="collection_text">Rekomendasi</div>
    <div class="collection_section">
    	<div class="container">
    		<h1 class="new_text"><strong>Recomend Sendal</strong></h1>
    	   </div>
    </div>
    <div class="collectipn_section_3 layuot_padding">
    	<div class="container">
    		<div class="racing_shoes">
    			<div class="row">
				@php
                $sandal = App\Sandal::find([11]);
                @endphp
				@foreach ($sandal as $sans)
    				<div class="col-md-8">
    					<div class="shoes-img"><img src="{{ asset('assets/images/avatar/'.$sans->gambar.'') }}"></div>
    				</div>
    				<div class="col-md-4">
    					<div class="sale_text"><strong>Recomend <br><span style="color: #0a0506;">{{ $sans->nama }}</span></strong></div>
    					<div class="number_text"><strong>Rp. <span style="color: #ff4e5b;">{{ number_format($sans->harga,2,',','.') }}</span></strong></div>
    					<br>
							<center><a href="{{url('add-cart',$sans->id)}}" class="btn btn-primary" style="width: 250px; margin-left: 10px;">Beli</a></center>
							<br>
    				</div>
    			</div>
				@endforeach
    		</div>
    	</div>
    </div>
    		</div>
            
    		</div>
</div>
   	<!-- New Arrivals section end -->
       @include('frontend.chat')
	<!-- section footer start -->
    	@include('frontend.footer')
