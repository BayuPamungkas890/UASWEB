@include('frontend.header')
	<!-- new collection section start -->
  <div class="collection_text">Terbaru</div>
    <div class="layout_padding collection_section">
    	<div class="container">
    	    <h1 class="new_text"><strong>Terbaru</strong></h1>
    	    <p class="consectetur_text"></p>
    	    <div class="collection_section_2">
    	    	<div class="row">
                @php
                $sandal = App\Sandal::orderby('created_at','DESC')->paginate(1);
                @endphp
                @foreach ($sandal as $sans)
				<div class="col-md-6">
    	    			<div class="about-img">
						<button class="new_bt">New</button>
    	    				<div class="shoes-img"><img src="{{ asset('assets/images/avatar/'.$sans->gambar.'') }}"></div>
    	    				<p class="sport_text">{{ $sans->nama }}</p>
    	    				<div class="dolar_text"><h3>Rp. <span style="color: #ff4e5b;">{{ number_format($sans->harga,2,',','.') }}</span></h3></center></div>
							<br>
							<center><a href="{{url('add-cart',$sans->id)}}" class="btn btn-primary" style="width: 250px; margin-left: 10px;">Beli</a></center>
							<br>
						</div>
    	    		</div>
                @endforeach
                @php
                $sandal = App\Sandal::orderbyRaw("RAND()")->paginate(1);
                @endphp
                @foreach ($sandal as $sanst)    
				<div class="col-md-6">
    	    			<div class="about-img">
    	    				<div class="shoes-img"><img src="{{ asset('assets/images/avatar/'.$sanst->gambar.'') }}"></div>
    	    				<p class="sport_text">{{ $sanst->nama }}</p>
    	    				<div class="dolar_text"<h3>Rp. <span style="color: #ff4e5b;">{{ number_format($sanst->harga,2,',','.') }}</span></h3></center></div>
							<br>
							<center><a href="{{url('add-cart',$sanst->id)}}" class="btn btn-primary" style="width: 250px; margin-left: 10px;">Beli</a></center>
							<br>
						</div>
    	    		</div>
                    @endforeach
    	    	</div>
    	    </div>
    	</div>
    </div>
	</div>
	<!-- new collection section end -->
    @include('frontend.chat')
	<!-- section footer start -->
   @include('frontend.footer')