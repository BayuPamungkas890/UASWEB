@extends('layouts.admin')
@section('content')
<h1 ><center><u>Kontak</u></center></h1>

<div class="row">
	<div class="container">
		<div class="col-md-10" style="float:right">
			<div class="panel panel-info">
				<div class="panel-heading">
			</div>
<div class="panel-body">
	<div class="table-responsive">
		<table class="table" style="float:right">
			<thead>
				<tr>
					<th>No</th>
					<th>Nama</th>
                    <th>Telepon</th>
                    <th>Email</th>
                    <th>Pesan</th>
				</tr>	
</thead>
<tbody>
	@php $no = 1; @endphp
	@foreach($kontak as $data)
	<tr>
		<td> {{ $no++ }} </td>
		<td> {{ $data->nama }} </td>
        <td> {{ $data->tlp}} </td>
        <td> {{ $data->email}} </td>
        <td> {{ $data->ket}} </td>
	<td>
						</td>
</tr>
@endforeach
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
@endsection