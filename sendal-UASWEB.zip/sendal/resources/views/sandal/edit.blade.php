@extends('layouts.admin')
@section('content')
<div class="row">
	<div class="container">
    <div class="col-md-10" style="float:right">
			<div class="panel panel-info">
			  <div class="panel-heading">
			  	<div class="panel-title pull-right"><a href="{{ route('sandal.index') }}" class="btn-outline-warning"><i class="fa fa-chevron-circle-left">&nbsp</i>Kembali</a>
			  	</div>
			  </div>
			  <div class="panel-body">
			  	<form action="{{ route('sandal.update',$sandal->id) }}" method="post" enctype="multipart/form-data">
			  		<input name="_method" type="hidden" value="PATCH">
        			{{ csrf_field() }}
			  		<div class="form-group {{ $errors->has('nama') ? ' has-error' : '' }}">
			  			<label class="control-label">nama</label>	
			  			<input type="text" name="nama" class="form-control" value="{{ $sandal->nama }}"  required>
			  			@if ($errors->has('nama'))
                            <span class="help-block">
                                <strong>{{ $errors->first('nama') }}</strong>
                            </span>
                        @endif
			  		</div>

			  		<div class="form-group {{ $errors->has('ket') ? ' has-error' : '' }}">
			  			<label class="control-label">ket</label>	
			  			<textarea id="text" type="ckeditor" name="ket" class="ckeditor" required>{{ $sandal->ket }}</textarea>
			  			@if ($errors->has('ket'))
                            <span class="help-block">
                                <strong>{{ $errors->first('ket') }}</strong>
                            </span>
                        @endif
			  		</div>


					<div class="form-group {{ $errors->has('gambar') ? ' has-error' : '' }}">
			  			<label class="control-label col-md-3 col-sm-3 col-xs-3  ">Gambar</label>
			  			<div class="col-md-9 pr-1">	
			  			<input type="file" name="gambar" accept="image/*" class="form-control" value="{{ $sandal->gambar }}">
			  			@if (isset($sandal) && $sandal->gambar)
                                            <p>
                                                <br>
                                            <img src="{{ asset('/assets/images/avatar/'.$sandal->gambar) }}" style="width:100px; height:100px;" alt="">
                                            </p>
                            <span class="help-block">
                                <strong>{{ $errors->first('gambar') }}</strong>

                            </span>
                        @endif
			  		</div>

			  		<div class="form-group {{ $errors->has('harga') ? ' has-error' : '' }}">
			  			<label class="control-label">harga</label>	
			  			<input type="number" name="harga" class="form-control" value="{{ $sandal->harga }}"  required>
			  			@if ($errors->has('harga'))
                            <span class="help-block">
                                <strong>{{ $errors->first('harga') }}</strong>
                            </span>
                        @endif
			  		</div>

			  		<div class="form-group {{ $errors->has('merk_id') ? ' has-error' : '' }}">
			  			<label class="control-label">Merk</label>	
			  			<select name="merk_id" class="form-control">
			  				@foreach($merk as $data)
			  				<option value="{{ $data->id }}" {{ $selectedMerk == $data->id ? 'selected="selected"' : '' }} >{{ $data->nama_merk }}</option>
			  				@endforeach
			  			</select>
			  			@if ($errors->has('merk_id'))
                            <span class="help-block">
                                <strong>{{ $errors->first('merk_id') }}</strong>
                            </span>
                        @endif
			  		</div>
			 
			  		<div class="form-group">
			  			<button type="submit" class="btn btn-outline-primary">
			  			<i class="fa fa-save">&nbsp</i>Edit</button>
			  			<button type="reset" class="btn btn-outline-success">
						<i class="fa fa-refresh fa-spin"></i>&nbsp ulangi</button>
			  		</div>
			  	</form>
			  </div>
			</div>	
		</div>
	</div>
	<script type="text/javascript" src="{{asset('ckeditor/ckeditor.js')}}"></script>
</div>
@endsection