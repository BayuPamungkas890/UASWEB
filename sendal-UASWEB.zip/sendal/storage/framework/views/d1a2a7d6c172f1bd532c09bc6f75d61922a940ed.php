<?php echo $__env->make('frontend.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- new collection section start -->
  <div class="collection_text">Terbaru</div>
    <div class="layout_padding collection_section">
    	<div class="container">
    	    <h1 class="new_text"><strong>Terbaru</strong></h1>
    	    <p class="consectetur_text"></p>
    	    <div class="collection_section_2">
    	    	<div class="row">
                <?php
                $sandal = App\Sandal::orderby('created_at','DESC')->paginate(1);
                ?>
                <?php $__currentLoopData = $sandal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-md-6">
    	    			<div class="about-img">
						<button class="new_bt">New</button>
    	    				<div class="shoes-img"><img src="<?php echo e(asset('assets/images/avatar/'.$sans->gambar.'')); ?>"></div>
    	    				<p class="sport_text"><?php echo e($sans->nama); ?></p>
    	    				<div class="dolar_text"><h3>Rp. <span style="color: #ff4e5b;"><?php echo e(number_format($sans->harga,2,',','.')); ?></span></h3></center></div>
							<br>
							<center><a href="<?php echo e(url('add-cart',$sans->id)); ?>" class="btn btn-primary" style="width: 250px; margin-left: 10px;">Beli</a></center>
							<br>
						</div>
    	    		</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php
                $sandal = App\Sandal::orderbyRaw("RAND()")->paginate(1);
                ?>
                <?php $__currentLoopData = $sandal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sanst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
				<div class="col-md-6">
    	    			<div class="about-img">
    	    				<div class="shoes-img"><img src="<?php echo e(asset('assets/images/avatar/'.$sanst->gambar.'')); ?>"></div>
    	    				<p class="sport_text"><?php echo e($sanst->nama); ?></p>
    	    				<div class="dolar_text"<h3>Rp. <span style="color: #ff4e5b;"><?php echo e(number_format($sanst->harga,2,',','.')); ?></span></h3></center></div>
							<br>
							<center><a href="<?php echo e(url('add-cart',$sanst->id)); ?>" class="btn btn-primary" style="width: 250px; margin-left: 10px;">Beli</a></center>
							<br>
						</div>
    	    		</div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    	    	</div>
    	    </div>
    	</div>
    </div>
	</div>
	<!-- new collection section end -->
    <?php echo $__env->make('frontend.chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- section footer start -->
   <?php echo $__env->make('frontend.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>