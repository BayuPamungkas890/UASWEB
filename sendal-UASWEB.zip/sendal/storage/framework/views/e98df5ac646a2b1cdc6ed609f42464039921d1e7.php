<?php echo $__env->make('frontend.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<!-- breadcrumb -->
	<!-- <div class="container">
		<div class="bread-crumb flex-w p-l-25 p-r-15 p-t-30 p-lr-0-lg">
			<a href="index.html" class="stext-109 cl8 hov-cl1 trans-04">
				Home
				<i class="fa fa-angle-right m-l-9 m-r-10" aria-hidden="true"></i>
			</a>

			<span class="stext-109 cl4">
				Shoping Cart
			</span>
		</div>
	</div> -->
		
	
	<!-- Shoping Cart -->
		<div class="container">
			<div class="row">
				<div class="col-lg-10 col-xl-7 m-lr-auto m-b-50">
					<div class="m-l-25 m-r--38 m-lr-0-xl">
						<form method="post" action="<?php echo e(url('cart/edit/'.Auth::user()->id)); ?>">

							<?php echo e(csrf_field()); ?>

							<!-- <input name="_method" type="hidden" value="PATCH"> -->
							<div class="wrap-table-shopping-cart">
								<table class="table-shopping-cart">
									<tr class="table_head">
										<th class="column-1">Gambar</th>
										<th class="column-2">Nama</th>
										<th class="column-3">Harga</th>
										<th class="column-4">Jumlah</th>
										<th class="column-5">Total</th>
										<th class="column-6">Action</th>
									</tr>

									<?php
										$total_all = 0;
										$cart = \App\Cart::where('user_id', \Auth::user()->id)->get();
									?>

									<?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php 
										$t_s = $data->jumlah_brg * $data->sandal->harga;
										$total_all = $total_all + $t_s;
									?>
									<input type="hidden" name="id[]" value="<?php echo e($data->id); ?>">
									<tr class="table_row">
										<td class="column-1">
											<div class="how-itemcart1">
												<img src="<?php echo e(asset('assets/images/avatar/'.$data->sandal->gambar)); ?>" alt="IMG">
											</div>
										</td>
										<td class="column-2"><?php echo e($data->sandal->nama); ?></td>
										<td class="column-3"><?php echo e(number_format($data->sandal->harga,2,',','.')); ?></td>
										<td class="column-4">
											<div class="wrap-num-sandal flex-w m-l-auto m-r-0">
												<div class="btn-num-sandal-down cl8 hov-btn3 trans-04 flex-c-m">
													<i class="fs-16 zmdi zmdi-minus"></i>
												</div>

												<input class="mtext-104 cl3 txt-center num-sandal" type="number" name="jumlah_brg[]" value="<?php echo e($data->jumlah_brg); ?>">

												<div class="btn-num-sandal-up cl8 hov-btn3 trans-04 flex-c-m">
													<i class="fs-16 zmdi zmdi-plus"></i>
												</div>
											</div>
										</td>
										<td class="column-5"><?php echo e(number_format($data->jumlah_brg * $data->sandal->harga,2,',','.')); ?></td>
										<td>
											<a href="<?php echo e(url('cart/delete', $data->id)); ?>" class="btn btn-danger">X</a>
										</td>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
							</div>

							<div class="flex-w flex-sb-m bor15 p-t-18 p-b-15 p-lr-40 p-lr-15-sm">

								<div class="btn btn-danger">
									<button type="submit" class="btn btn-danger"><i class="fa fa-pencil-square-o nav-icon"></i> Ubah Keranjang</button>
								</div>
							</div>

						</form>
					</div>
				</div>

				<div class="col-sm-10 col-lg-7 col-xl-5 m-lr-auto m-b-50">
					<div class="bor10 p-lr-40 p-t-30 p-b-40 m-l-63 m-r-40 m-lr-0-xl p-lr-15-sm">
						<h4 class="mtext-109 cl2 p-b-30">
							Semua Total
						</h4>

						<div class="flex-w flex-t p-t-27 p-b-33">
							<form action="<?php echo e(url('checkout/'.Auth()->user()->id)); ?>" method="post" enctype="multipart/form-data" >
						  		<?php echo e(csrf_field()); ?>

						  		<input type="hidden" name="chart" value="<?php echo e($cart); ?>">
						  		<div class="size-208">
									<span class="mtext-101 cl2">
										Total:  Rp.<?php echo e(number_format($total_all,2,',','.')); ?>

									</span>
								</div>
						  		<div class="form-group <?php echo e($errors->has('alamat') ? ' has-error' : ''); ?>">
						  			<label class="control-label">Alamat <i class="fa fa-map-marker nav-icon"></i></label>	
						  			<textarea name="alamat" class="form-control"  required></textarea> 
						  			<?php if($errors->has('alamat')): ?>
			                            <span class="help-block">
			                                <strong><?php echo e($errors->first('alamat')); ?></strong>
			                            </span>
			                        <?php endif; ?>
						  		</div>

						  		<div class="form-group <?php echo e($errors->has('no_tlp') ? ' has-error' : ''); ?>">
						  			<label class="control-label">No Telepon <i class="fa fa-mobile nav-icon"></i></label>	
						  			<input type="number" name="no_tlp" class="form-control"  required>
						  				<?php if($errors->has('no_tlp')): ?>
			                            <span class="help-block">
			                                <strong><?php echo e($errors->first('no_tlp')); ?></strong>
			                            </span>
			                        <?php endif; ?>
						  		</div>

								<div class="form-group <?php echo e($errors->has('pembayaran') ? ' has-error' : ''); ?>">
						  			<label class="control-label">Pembayaran <i class="fa fa-money nav-icon"></i></label>
						  			<select class="form-control" name="pembayaran" required>
															<option>Bayar ditempat</option>
														
						  			<?php if($errors->has('pembayaran')): ?>
			                            <span class="help-block">
			                                <strong><?php echo e($errors->first('pembayaran')); ?></strong>
			                            </span>
			                        <?php endif; ?>
									</select>
						  		</div>
								  <br><br>

						  		<div class="form-group <?php echo e($errors->has('pengiriman') ? ' has-error' : ''); ?>">
						  			<label class="control-label">Pengiriman <i class="fa fa-car nav-icon"></i>&nbsp<i class="fa fa-motorcycle nav-icon"></i></label>
						  			<select class="form-control" name="pengiriman" required>
															<option>JNE</option>
															<option>J&T</option>
															<option>Indah Cargo</option>
															<option>Lega Paket</option>
						  			<?php if($errors->has('pengiriman')): ?>
			                            <span class="help-block">
			                                <strong><?php echo e($errors->first('pengiriman')); ?></strong>
			                            </span>
			                        <?php endif; ?>
									</select>
						  		</div>

							<div class="size-209 p-t-1">
								<span class="mtext-110 cl2">
									
								</span>
							</div>
						</div>
						<br><br>

							<button  type="submit" class="btn btn-success">
								<i class="fa fa-credit-card-alt">&nbsp Bayar Semua Produk</i>
							</button>
							
							
						</form>
						</div>
					</div>
				</div>
			</div>
		</div>

	<!-- Footer -->
	<?php echo $__env->make('frontend.chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('frontend.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>