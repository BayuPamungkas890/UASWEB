<?php $__env->startSection('content'); ?>
<h1 ><center><u>Kontak</u></center></h1>

<div class="row">
	<div class="container">
		<div class="col-md-10" style="float:right">
			<div class="panel panel-info">
				<div class="panel-heading">
			</div>
<div class="panel-body">
	<div class="table-responsive">
		<table class="table" style="float:right">
			<thead>
				<tr>
					<th>No</th>
					<th>Nama</th>
                    <th>Telepon</th>
                    <th>Email</th>
                    <th>Pesan</th>
				</tr>	
</thead>
<tbody>
	<?php $no = 1; ?>
	<?php $__currentLoopData = $kontak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td> <?php echo e($no++); ?> </td>
		<td> <?php echo e($data->nama); ?> </td>
        <td> <?php echo e($data->tlp); ?> </td>
        <td> <?php echo e($data->email); ?> </td>
        <td> <?php echo e($data->ket); ?> </td>
	<td>
						</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>