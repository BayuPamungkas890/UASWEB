<?php echo $__env->make('frontend.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- New Arrivals section start -->
  <div class="collection_text">Sendal</div>
    <div class="collection_section layout_padding">
    	<div class="container">
    		<h1 class="new_text"><strong><font color="white">Koleksi Sendal</font></strong></h1>
    	    <p class="consectetur_text"><font color="white"> Produk terbaik dari Toko Kami.</p>
    	</div>
    </div>
    <?php
$sandal = App\Sandal::orderby('created_at','DESC')->get();
?>

	<!-- New Arrivals section start -->
    <div class="layout_padding gallery_section">
    	<div class="container">
    		<div class="row">
    		<?php $__currentLoopData = $sandal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>	
            <div class="col-sm-4">
                
    				<div class="best_shoes">
    					<p class="best_text"><center><h5><?php echo e($sans->nama); ?></h5></center></p>
						<center><h5>- <?php echo e($sans->Merk->nama_merk); ?> -</h5></center></p>
    					<div class="shoes_icon"><img src="<?php echo e(asset('assets/images/avatar/'.$sans->gambar.'')); ?>" style="width: 250px; height: 300px;"></div>
    					<div class="star_text">
    						<div class="right_part">
    							<div class="shoes_price"><h4>Rp. <span style="color: #ff4e5b;"><?php echo e(number_format($sans->harga,2,',','.')); ?></span></h4></div>
								<br>
								<center><a href="<?php echo e(url('add-cart',$sans->id)); ?>" class="btn btn-primary" style="width: 250px; margin-left: 50px;">Beli</a></center>
    						</div>
    					</div>
    				</div>
                
    			</div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
    		</div>
            
    		</div>
</div>
   	<!-- New Arrivals section end -->
       <?php echo $__env->make('frontend.chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- section footer start -->
    	<?php echo $__env->make('frontend.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
