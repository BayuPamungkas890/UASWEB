<?php $__env->startSection('content'); ?>
<h1 ><center><u>Merk Sendal</u></center></h1>

<div class="row">
	<div class="container">
		<div class="col-md-10" style="float:right">
			<div class="panel panel-info">
				<div class="panel-heading">
					<div class="panel-title pull-right"><a href="<?php echo e(route('merk.create')); ?>" class="btn-outline-warning"><i class="fa fa-plus-square">&nbsp</i> Add </a>
				</div>
			</div>
<div class="panel-body">
	<div class="table-responsive">
		<table class="table" style="float:right">
			<thead>
				<tr>
					<th>No</th>
					<th>Nama Merk</th>
					<th colspan="3">Action</th>
				</tr>	
</thead>
<tbody>
	<?php $no = 1; ?>
	<?php $__currentLoopData = $merk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td> <?php echo e($no++); ?> </td>
		<td> <?php echo e($data->nama_merk); ?> </td>
	<td>
		<a class="btn btn-outline-primary" href=" <?php echo e(route('merk.edit',$data->id)); ?> "><i class="fa fa-file-text">&nbsp</i>Edit</a>
	</td>
	<td>
							<form method="post" action="<?php echo e(route('merk.destroy',$data->id)); ?>">
								<input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">
								<input type="hidden" name="_method" value="DELETE">

								<button type="submit" class="btn btn-outline-danger"><i class="fa fa-trash"></i>Delete</button>
							</form>
						</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>