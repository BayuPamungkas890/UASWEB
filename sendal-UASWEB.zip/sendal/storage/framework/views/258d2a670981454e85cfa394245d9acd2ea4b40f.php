<?php echo $__env->make('frontend.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
   	<!-- contact section start -->
    <div class="collection_text">Contact Us</div>
    <div class="layout_padding contact_section">
    	<div class="container">
    		<h1 class="new_text"><strong>Contact Now</strong></h1>
    	</div>

        <?php if(Session::has('status')): ?>
        <div class="alert alert-success"><?php echo e(Session::get('status')); ?></div>
        <?php endif; ?>

    	<div class="container-fluid ram">
    		<div class="row">
    			<div class="col-md-6">
    				<div class="email_box">
                    <div class="input_main">
                       <div class="container">
                          <form action="<?php echo e(route('kontak.store')); ?>" method="post" enctype="multipart/form-data">
                          <?php echo e(csrf_field()); ?>

                            <div class="form-group <?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
                              <input type="text" class="email-bt" placeholder="Nama" name="nama">
                              <?php if($errors->has('nama')): ?>
                                        <span class="help-block">
                                <strong><?php echo e($errors->first('nama')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group <?php echo e($errors->has('tlp') ? ' has-error' : ''); ?>">
                              <input type="text" class="email-bt" placeholder="Telepon" name="tlp">
                              <?php if($errors->has('tlp')): ?>
                                        <span class="help-block">
                                <strong><?php echo e($errors->first('tlp')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>

                            <div class="form-group <?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                              <input type="text" class="email-bt" placeholder="Email" name="email">
                              <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="form-group <?php echo e($errors->has('ket') ? ' has-error' : ''); ?>">
                                <textarea class="massage-bt" placeholder="Keterangan" rows="5" id="comment" name="ket"></textarea>
                                <?php if($errors->has('ket')): ?>
                                        <span class="help-block">
                                <strong><?php echo e($errors->first('ket')); ?></strong>
                                        </span>
                                <?php endif; ?>
                            </div>
                          </form>   
                       </div> 
                       <div class="form-group">
			  			<button type="submit" class="btn btn-outline-primary">
			  			<i class="fa fa-save">&nbsp</i>Tambah</button>
			  			<button type="reset" class="btn btn-outline-success">
						<i class="fa fa-refresh fa-spin"></i>&nbsp ulangi</button>
			  		</div>                   
                    </div>
    		</div>
    			</div>
    			<div class="col-md-6">
    				<div class="shop_banner">
    					<div class="our_shop">
    						<button class="out_shop_bt">Our Shop</button>
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
   	<!-- contact section end -->
	<!-- section footer start -->
    <?php echo $__env->make('frontend.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
