<?php echo $__env->make('frontend.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- New Arrivals section start -->
  <div class="collection_text">Rekomendasi</div>
    <div class="collection_section">
    	<div class="container">
    		<h1 class="new_text"><strong>Recomend Sendal</strong></h1>
    	   </div>
    </div>
    <div class="collectipn_section_3 layuot_padding">
    	<div class="container">
    		<div class="racing_shoes">
    			<div class="row">
				<?php
                $sandal = App\Sandal::find([11]);
                ?>
				<?php $__currentLoopData = $sandal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    				<div class="col-md-8">
    					<div class="shoes-img"><img src="<?php echo e(asset('assets/images/avatar/'.$sans->gambar.'')); ?>"></div>
    				</div>
    				<div class="col-md-4">
    					<div class="sale_text"><strong>Recomend <br><span style="color: #0a0506;"><?php echo e($sans->nama); ?></span></strong></div>
    					<div class="number_text"><strong>Rp. <span style="color: #ff4e5b;"><?php echo e(number_format($sans->harga,2,',','.')); ?></span></strong></div>
    					<br>
							<center><a href="<?php echo e(url('add-cart',$sans->id)); ?>" class="btn btn-primary" style="width: 250px; margin-left: 10px;">Beli</a></center>
							<br>
    				</div>
    			</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    		</div>
    	</div>
    </div>
    		</div>
            
    		</div>
</div>
   	<!-- New Arrivals section end -->
       <?php echo $__env->make('frontend.chat', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- section footer start -->
    	<?php echo $__env->make('frontend.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
