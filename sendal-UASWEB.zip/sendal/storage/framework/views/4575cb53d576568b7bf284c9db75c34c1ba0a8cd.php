<?php $__env->startSection('content'); ?>

<div class="row">
	<div class="container">
    <div class="col-md-10" style="float:right">
			<div class="panel panel-info">
			  <div class="panel-heading">
			  	<div class="panel-title pull-right"><a href="<?php echo e(route('sandal.index')); ?>" class="btn-outline-warning"><i class="fa fa-chevron-circle-left">&nbsp</i>Kembali</a>
			  	</div>
			  </div>
			  <div class="panel-body">
			  	<form action="<?php echo e(route('sandal.store')); ?>" method="post" enctype="multipart/form-data" >
			  		<?php echo e(csrf_field()); ?>

			  		<div class="form-group <?php echo e($errors->has('nama') ? ' has-error' : ''); ?>">
			  			<label class="control-label">Nama Sandal</label>	
			  			<input type="text" name="nama" class="form-control"  required>
			  			<?php if($errors->has('nama')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('nama')); ?></strong>
                            </span>
                        <?php endif; ?>
			  		</div>

			  		<div class="form-group <?php echo e($errors->has('ket') ? ' has-error' : ''); ?>">
			  			<label class="control-label">Ket / Merk</label>	
			  			<textarea id="text" type="text" name="ket" class="ckeditor" required="">
			  			</textarea>
			  			<?php if($errors->has('ket')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('ket')); ?></strong>
                            </span>
                        <?php endif; ?>
			  		</div>

			  		<div class="form-group <?php echo e($errors->has('gambar') ? ' has-error' : ''); ?>">
			  			<label class="control-label col-md-3 col-sm-3 col-xs-3  ">Gambar</label>
			  			<div class="col-md-9 pr-1">
			  			<input type="file" name="gambar" class="form-control"  required>
			  			<?php if($errors->has('gambar')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('gambar')); ?></strong>
                            </span>
                        <?php endif; ?>
			  		</div>

			  		<div class="form-group <?php echo e($errors->has('harga') ? ' has-error' : ''); ?>">
			  			<label class="control-label">Harga</label>	
			  			<input type="text" name="harga" class="form-control"  required>
			  			<?php if($errors->has('harga')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('harga')); ?></strong>
                            </span>
                        <?php endif; ?>
			  		</div>

			  		<div class="form-group <?php echo e($errors->has('merk_id') ? ' has-error' : ''); ?>">
			  			<label class="control-label">Merk</label>	
			  			<select name="merk_id" class="form-control">
			  				<?php $__currentLoopData = $merk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			  				<option value="<?php echo e($data->id); ?>"><?php echo e($data->nama_merk); ?></option>
			  				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			  			</select>
			  			<?php if($errors->has('merk_id')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('merk_id')); ?></strong>
                            </span>
                        <?php endif; ?>
			  		</div>
			  		</div>

			  		
			  		<div class="form-group">
			  			<button type="submit" class="btn btn-outline-primary">
			  			<i class="fa fa-save">&nbsp</i>Tambah</button>
			  			<button type="reset" class="btn btn-outline-success">
						<i class="fa fa-refresh fa-spin"></i>&nbsp ulangi</button>
			  		</div>
			  	</form>
			  </div>
			</div>	
		</div>
	</div>
	<script type="text/javascript" src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>