<?php $__env->startSection('content'); ?>
<h1><center><u>Laporan Penjualan</u></center></h1>

<div class="row">
	<div class="container">
    <div class="col-md-10" style="float:right">
			<div class="panel panel-info">
				<div class="panel-heading">
				</div>
			</div>
			<div class="panel-body">
	<div class="table-responsive">
		<table class="table">
			<thead>
				<tr>
                <th>No</th>
					<th>Gambar</th>
					<th>Nama custom</th>
					<th>Alamat</th>
					<th>No Telepon</th>
					<th>Product yang dipesan</th>
					<th>Harga sendal</th>
					<th>Jumlah sendal yang dipesan</th>
					<th>Pembayaran</th>
					<th>Pengiriman</th>
					<th>Tanggal Pemesanan</th>
					<th>Total</th>
					<th colspan="3">Action</th>
				</tr>	
</thead>
<tbody>
	<?php $no = 1; ?>
	<?php $__currentLoopData = $customNotif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
	<td> <?php echo e($no++); ?> </td>
		<td><img src="<?php echo e(asset('assets/images/avatar/'.$data->sandal->gambar)); ?>" style="max-width: 80px;"></td>
		<td> <?php echo e($data->nama); ?> </td>
		<td> <?php echo e($data->alamat); ?> </td>
		<td> <?php echo e($data->no_tlp); ?> </td>
		<td> <?php echo e($data->Sandal->nama); ?></td>
		<td> <?php echo e($data->Sandal->harga); ?></td>
		<td> <?php echo e($data->jumlah_brg); ?> </td>
		<td> <?php echo e($data->pembayaran); ?> </td>
		<td> <?php echo e($data->pengiriman); ?> </td>
        <td> <?php echo e(date('M j, Y', strtotime($data->created_at))); ?></td>
		<td> <?php echo e($data->Product->harga * $data->jumlah_brg); ?> </td>

	<td>
	<a href="<?php echo e(route('invoice.print', $data->id)); ?>" class="btn-success btn-secondary btn-sm">Print</a>
						</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
</div>
</div>
</div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>