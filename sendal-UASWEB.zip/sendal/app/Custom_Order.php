<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Custom_Order extends Model
{
    protected $table = 'custom_orders';
    protected $fillable = ['nama', 'alamat', 'no_tlp', 'pengiriman', 'jumlah_brg', 'pembayaran', 'ukuran', 'sandal_id', 'user_id'];
    public $timestamps = true;

   public function sandal()
    {
        return $this->belongsTo('App\Sandal','sandal_id');
    }
    public function user()
    {
        return $this->belongsTo('App\User','user_id');
    }
}
