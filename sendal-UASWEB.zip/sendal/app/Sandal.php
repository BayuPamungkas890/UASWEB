<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sandal extends Model
{
    protected $table = 'sandals';
    protected $fillable = ['nama','ket','gambar','slug','harga','merk_id'];
    public $timestamps = true;

    public function merk(){
        return $this->belongsTo('App\Merk','merk_id');
    }

    public function getRouteKeyName(){
        return 'slug';    
    }
    
    public function custom()
    {
    	return $this->hasMany('App\Custom','sandal_id');
    }
}
