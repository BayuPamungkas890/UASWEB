<?php

namespace App\Http\Controllers;

use App\Sandal;
use App\Merk;
use File;
use Illuminate\Http\Request;

class SandalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct(){
        $this->middleware('auth');
    }

    public function index()
    {
        $sandal = Sandal::All();
        return view('sandal.index',compact('sandal'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $merk = Merk::all();
        return view('sandal.create',compact('merk'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'nama' => 'required|',
            'ket' => 'required|',
            'gambar' => 'required|',
            'harga' => 'required|',
            'merk_id' => 'required|'
        ]);


        $sandal = new sandal;
        // $sandal = sandal::orderBy('created_at', 'DESC')->get();
        $sandal->nama = $request->nama;
        $sandal->slug=str_slug($request->nama, '-');
        $sandal->ket = $request->ket;
        $sandal->gambar = $request->gambar;
        $sandal->harga = $request->harga;
        $sandal->merk_id = $request->merk_id;

        if ($request->hasFile('gambar')) {
            $file = $request->file('gambar');
            $destinationPath = public_path().'/assets/images/avatar/';
            $filename = str_random(6).'_'.$file->getClientOriginalName();
            $uploadSuccess = $file->move($destinationPath, $filename);
            $sandal->gambar = $filename;
        }
        
        $sandal->save();
        return redirect()->route('sandal.index');
    
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Sandal  $sandal
     * @return \Illuminate\Http\Response
     */
    public function show(Sandal $sandal)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Sandal  $sandal
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $sandal = Sandal::findOrFail($id);
        $merk = Merk::all();
        $selectedMerk = Sandal::findOrFail($id)->merk_id;
      
        return view('sandal.edit',compact('sandal','merk','selectedMerk'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Sandal  $sandal
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Sandal $sandal)
    {
        $this->validate($request,[
            'nama' => 'required|',
            'ket' => 'required|',
            'gambar' => 'required|',
            'harga' => 'required|',
            'merk_id' => 'required|'
        ]);
        $sandal = Sandal::findOrFail($id);
        $sandal->nama = $request->nama;
        $sandal->slug=str_slug($request->nama, '-');
        $sandal->ket = $request->ket;
        $sandal->gambar = $request->gambar;
        $sandal->harga = $request->harga;
        $sandal->merk_id = $request->merk_id;

        if ($request->hasFile('gambar')) {
            $file = $request->file('gambar');
            $destinationPath = public_path().'/assets/images/avatar/';
            $filename = str_random(6).'_'.$file->getClientOriginalName();
            $uploadSuccess = $file->move($destinationPath, $filename);
        
        if ($sandal->gambar) {
        $old_foto = $sandal->gambar;
        $filepath = public_path() . DIRECTORY_SEPARATOR . '/assets/images/avatar'
        . DIRECTORY_SEPARATOR . $sandal->gambar;
            try {
            File::delete($filepath);
            } catch (FileNotFoundException $e) {
        // File sudah dihapus/tidak ada
            }
        }
        $sandal->gambar = $filename;
}
        $sandal->save();
        return redirect()->route('sandal.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Sandal  $sandal
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $sandal = Sandal::findOrFail($id);
         $sandal->delete();
        return redirect()->route('sandal.index');
    }
}
