<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Sandal;
use App\Kontak;

class FrontendController extends Controller
{
    public function sandal(){
        $sandals = Sandal::all();
        return view('frontend.index');
    }

    public function produk(){
        $sandals = Sandal::all();
        return view('frontend.sendal');
    }

    public function kontak(){
        $kontaks = Kontak::all();
        return view('frontend.kontak');
    }

    public function baru(){
        $sandals = Sandal::all();
        return view('frontend.baru');
    }

    public function rekomen(){
        $sandals = Sandal::all();
        return view('frontend.rekomendasi');
    }
}
