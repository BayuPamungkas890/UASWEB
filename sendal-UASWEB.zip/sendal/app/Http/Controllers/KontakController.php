<?php

namespace App\Http\Controllers;

use App\Kontak;
use Illuminate\Http\Request;

class KontakController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $kontak = Kontak::All();
        return view('kontak.index',compact('kontak'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('frontend.kontak');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'nama' => 'required|',
            'tlp' => 'required|',
            'email' => 'required|',
            'ket' => 'required|'
        ]);

        $kontak = new Kontak;
        $kontak->nama = $request->nama;
        $kontak->tlp = $request->tlp;
        $kontak->email = $request->email;
        $kontak->ket = $request->ket;
        $kontak->save();

        return redirect()->route('kontak.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Kontak  $kontak
     * @return \Illuminate\Http\Response
     */
    public function show(Kontak $kontak)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Kontak  $kontak
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $kontak = Kontak::findOrFail($id);
        return view('kontak.edit',compact('kontak'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Kontak  $kontak
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Kontak $kontak)
    {
        $this->validate($request,[
            'nama' => 'required|',
            'tlp' => 'required|',
            'email' => 'required|',
            'ket' => 'required|'
        ]);

        $kontak = Kontak::findOrFail($id);
        $kontak->nama = $request->nama;
        $kontak->tlp = $request->tlp;
        $kontak->email = $request->email;
        $kontak->ket = $request->ket;
        $kontak->save();

        return redirect()->route('kontak.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Kontak  $kontak
     * @return \Illuminate\Http\Response
     */
    public function destroy(Kontak $kontak)
    {
        $kontak = Kontak::findOrFail($id);
        $kontak->delete();
        return redirect()->route('kontak.index');
    }
}
